package kr.ac.skuniv.todospring.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import kr.ac.skuniv.todospirng.dto.Todo;
import kr.ac.skuniv.todospring.config.ApplicationConfig;
import kr.ac.skuniv.todospring.dao.TodoMapper;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=ApplicationConfig.class)
@Transactional
public class TodoMapperTest {
	@Autowired
	TodoMapper todoDao;
	
	@Before
	public void init() {
		System.out.println("before");
	}
	@After
	public void destory() {
		System.out.println("after");
	}
	
	@Test
	public void getTodos() {
		assertNotNull(todoDao.getTodos());
		//assertEquals(3, todoDao.getTodos().size());
	}
	@Test
	public void getTodo() {
		assertEquals("test", todoDao.getTodo(67).getTodo());
	}
	@Test
	@Transactional
	public void addTodo() {
		int size = todoDao.getTodos().size();
		Todo todo = new Todo();
		todo.setTodo("spring study 2222");
		System.out.println(todoDao.addTodo(todo));
		System.out.println(todo.getId());
		//System.out.println("test::"+id);
		assertEquals(size+1, todoDao.getTodos().size());;
	}
	
	@Test
	@Transactional
	public void updateTodo() {
		todoDao.updateTodo(67);
		assertEquals(true, todoDao.getTodo(67).isDone());
	}
	
	@Test
	@Transactional
	public void deleteTodo() {
		todoDao.deleteTodo(67);
		assertNull( todoDao.getTodo(67));		
	}
}
