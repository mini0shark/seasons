package kr.ac.skuniv.todospring;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import kr.ac.skuniv.todospring.config.ApplicationConfig;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=ApplicationConfig.class)
public class DemoApplicationTests {

	@Test
	public void contextLoads() {
	}

}
