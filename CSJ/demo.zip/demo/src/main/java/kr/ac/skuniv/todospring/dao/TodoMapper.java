package kr.ac.skuniv.todospring.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import kr.ac.skuniv.todospirng.dto.Todo;

@Mapper
public interface TodoMapper {
	public Todo getTodo(int id);
	public List<Todo> getTodos();
	public int addTodo(Todo todo);
	public void updateTodo(int id);
	public void deleteTodo(int id);
	
}
